package com.profile.payload.response;

import com.profile.entity.Role;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserInfoResponse {
	  private String user_id;
	  private String username;
	  private String email;
	  private Role role;
	  private String token;
	  //private String type = "Bearer";
	/*public String getId() {
		return user_id;
	}
	public void setId(String id) {
		this.user_id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Role getRoles() {
		return this.role;
	}
	public void setRoles(Role role) {
		this.role = role;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public UserInfoResponse(String id, String username, String email, List<String> roles, String token) {
		super();
		this.user_id = id;
		this.username = username;
		this.email = email;
		this.role = role;
		this.token = token;
//		this.type = type;
	}*/

	@Override
	public String toString() {
		return "UserInfoResponse [id=" + user_id + ", username=" + username + ", email=" + email + ", roles=" + role
				+ ", token=" + token ;//+ ", type=" + type + "]";
	}
	  
	  

	}
