package com.profile.payload.request;

import com.profile.entity.Role;
import lombok.*;

import java.util.Set;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class SignUpRequest {
	  //@NotBlank
	 // @Size(min = 3, max = 20)
	  private String username;

	  //@NotBlank
	  //@Size(max = 50)
	 // @Email
	  private String email;

	  private Role role;

	 // @NotBlank
	 // @Size(min = 8, max = 40)
	  private String password;

}