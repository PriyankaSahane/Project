package com.profile.entity;

import java.util.Optional;

public enum Role {
    USER,
    ADMIN;

    public static Role fromString(String roleStr) {
        if (roleStr == null) {
            return USER; // default role
        }
        try {
            return Role.valueOf(roleStr.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return USER; // fallback to USER if input is invalid
        }
    }


}
