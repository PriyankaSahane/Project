package com.profile.entity;


import jakarta.persistence.*;
import lombok.NoArgsConstructor;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
@Table(name= "user", uniqueConstraints= @UniqueConstraint(columnNames="email"))
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String userid;

    @Column(name= "Name" ,unique = true, nullable = false)
    private String userName;

   // @Column(unique = true, nullable = false)
    private String email;

    //@Column(nullable = false)
    private String password;

    //@Enumerated(EnumType.STRING) // Store enum as String in DB
    //@Column(nullable = false)
    private Role role;

    public User() {
    }

    public User(String  userid, String name, String email, String password, Role role) {
        this.userid = userid;
        this.userName = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public String getId() {
        return userid;
    }

    public void setId(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return userName;
    }

    public void setUsername(String username) {
        this.userName = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + userid +
                ", username='" + userName + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", role=" + role +
                '}';
    }
}
