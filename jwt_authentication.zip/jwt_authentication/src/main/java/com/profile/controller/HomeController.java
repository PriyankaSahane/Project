package com.profile.controller;

import com.profile.entity.User;
import com.profile.service.UserService;
import com.profile.service.impl.UserDetailsImpl;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/home")
public class HomeController {
    //http://localhost:8081/home/user


    //Logger logger = LoggerFactory.getLogger(HomeController.class);

    /*@Autowired
    private UserDetailsImpl userServiceImpl;
    @GetMapping("/user")
    public List<User> getUser(){
        System.out.println("Priyanka123");
        return this.userServiceImpl.getUserList();
    }
    @GetMapping("/current-user")
    public String getLoggedInUser(Principal principal){
        return principal.getName();
    }

    /*@RequestMapping("/test")
    public String test(){
        this.logger.warn("This is working message");
        return " testing message";
    }*/

}
