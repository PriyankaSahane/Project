package com.profile.service;


import java.security.Principal;

public interface UserService {



    public String getLoggedInUser(Principal principal);

 }
