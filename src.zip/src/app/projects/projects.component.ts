import { Component, OnInit } from '@angular/core';
import { Project } from '../models/models';

@Component({
  selector: 'app-projects',
  imports: [],
  templateUrl: './projects.component.html',
  styleUrl: './projects.component.css'
})
export class ProjectsComponent implements OnInit {
  projects: Project[] = [
    {
      title: 'Inspire Brands',
      technologies: 'Backend Development, Java, Spring boot',
      description: [
        'Worked as junior backend developer in client project, Where I gained hands-on experience in following technologies Java 8, Spring boot, MySQL.',
      ],
    }
   
  ];
  constructor() {}

  ngOnInit(): void {}

}
