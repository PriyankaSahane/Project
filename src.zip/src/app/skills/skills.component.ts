import { Component, OnInit } from '@angular/core';
import { Skill } from '../models/models';

@Component({
  selector: 'app-skills',
  imports: [],
  templateUrl: './skills.component.html',
  styleUrl: './skills.component.css'
})
export class SkillsComponent implements OnInit {
  skills: Skill[] = [
    {
      name: 'Java 8',
      level: 'Intermediate'
      //rating: 40,
    },
    {
      name: 'Spring boot',
      level: 'Intermidiate'
      //rating: 3,
    },
    {
      name: 'HTML, CSS, JS',
      level: 'Intermediate',
      //rating: 3,
    },
    {
      name: 'C++',
      level: 'Intermidiate',
      //rating: 2,
    },
  ];
  constructor() {}

  ngOnInit(): void {}


}
