import { Component, OnInit } from '@angular/core';
import { WorkExperience } from '../models/models';

@Component({
  selector: 'app-experience',
  imports: [],
  templateUrl: './experience.component.html',
  styleUrl: './experience.component.css'
})
export class ExperienceComponent implements OnInit {
  workExpList: WorkExperience[] = [
    {
      role: 'Software Engineer',
      company: 'Capgemini',
      duration: 'July 2023 - PRESENT',
      description: [
        'I have worked experience in backend development.'
      ],
    },
  ];
  constructor() {}

  ngOnInit(): void {}

}
