import { Component, OnInit } from '@angular/core';
import { Education } from '../models/models';

@Component({
  selector: 'app-education',
  imports: [],
  templateUrl: './education.component.html',
  styleUrl: './education.component.css'
})
export class EducationComponent implements OnInit {

  educationList: Education[] = [
    {
      institute: "JSPM's Rajarshi Shahu College of Engineering, Pune",
      course: 'MCA',
      duration: '2021-2023',
      score: '80%',
    },
    {
      institute: 'RNC Arts, JDB Commerce and NSC Science College,Nashik',
      course: 'BCA',
      duration: '2018-2021',
      score: '81%',
    },
    {
      institute: 'S.V.K.T. College - Savitribai Phule Pune University',
      course: 'HSC',
      duration: '2016-2018',
      score: '72%',
    },
    {
      institute: 'Deolali High School, Deolali Camp',
      course: 'SSC',
      duration: '2016',
      score: '81%',
    }
  ];

  constructor() {}

  ngOnInit(): void {}

}
